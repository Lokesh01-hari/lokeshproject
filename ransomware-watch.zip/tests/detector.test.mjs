import test from 'node:test';
import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import {
  Analyzer, diffSnapshots, classify, shannonEntropy, looksLikeRansomNote, isSuspiciousExt,
} from '../docs/detector.js';

const snap = (obj) => new Map(Object.entries(obj));
const f = (size, mtime, ent = null) => ({ size, mtime, ent });

test('entropy: text is low, random bytes are high', () => {
  const text = Buffer.from('the quick brown fox jumps over the lazy dog. '.repeat(400));
  assert.ok(shannonEntropy(text) < 5);
  assert.ok(shannonEntropy(randomBytes(16384)) > 7.9);
  assert.equal(shannonEntropy(new Uint8Array(0)), 0);
});

test('diff: created, modified, deleted', () => {
  const prev = snap({ 'a.txt': f(10, 1), 'b.txt': f(10, 1) });
  const curr = snap({ 'a.txt': f(12, 2), 'c.txt': f(5, 3) });
  const kinds = Object.fromEntries(diffSnapshots(prev, curr).map(c => [c.path, c.kind]));
  assert.deepEqual(kinds, { 'a.txt': 'modified', 'c.txt': 'created', 'b.txt': 'deleted' });
});

test('diff: same size+mtime delete/create is a rename', () => {
  const prev = snap({ 'old.txt': f(10, 5) });
  const curr = snap({ 'new.txt': f(10, 5) });
  const [c] = diffSnapshots(prev, curr);
  assert.equal(c.kind, 'renamed');
  assert.equal(c.from, 'old.txt');
  assert.equal(c.appended, false);
});

test('diff: appended extension detected even when contents changed', () => {
  const prev = snap({ 'docs/report.docx': f(100, 1) });
  const curr = snap({ 'docs/report.docx.locked': f(140, 9) });
  const [c] = diffSnapshots(prev, curr);
  assert.equal(c.kind, 'renamed');
  assert.equal(c.appended, true);
  assert.deepEqual(classify(c).sort(), ['appended', 'ext']);
});

test('signal helpers', () => {
  assert.ok(isSuspiciousExt('x/a.docx.lockbit'));
  assert.ok(!isSuspiciousExt('yarn.lock'));
  assert.ok(looksLikeRansomNote('HOW_TO_DECRYPT_FILES.txt'));
  assert.ok(looksLikeRansomNote('!!!READ_ME!!!.html'));
  assert.ok(!looksLikeRansomNote('README.md'));
  assert.ok(!looksLikeRansomNote('readme.txt'));
});

test('entropy signal ignores naturally compressed formats', () => {
  const high = { kind: 'modified', path: 'photo.jpg', ent: 7.9, prevEnt: 7.9 };
  assert.deepEqual(classify(high), []);
  const jump = { kind: 'modified', path: 'notes.txt', ent: 7.95, prevEnt: 4.2 };
  assert.deepEqual(classify(jump), ['entropy']);
  const docxJump = { kind: 'modified', path: 'a.docx', ent: 7.95, prevEnt: 4.2 };
  assert.deepEqual(classify(docxJump), []);
});

test('normal editing stays calm', () => {
  const a = new Analyzer();
  const now = 1_000_000;
  a.ingest([{ kind: 'modified', path: 'notes.txt', ent: 4.5, prevEnt: 4.4 }], now);
  a.ingest([{ kind: 'created', path: 'draft.md', ent: 4.1, prevEnt: null }], now + 1000);
  assert.equal(a.assess(now + 2000).level, 'calm');
});

test('a plain burst (10 changes / 5 s) is "watch", not "alert"', () => {
  const a = new Analyzer();
  const now = 1_000_000;
  const burst = Array.from({ length: 10 }, (_, i) => ({ kind: 'modified', path: `f${i}.txt`, ent: 4, prevEnt: 4 }));
  a.ingest(burst, now);
  const r = a.assess(now + 100);
  assert.equal(r.level, 'watch');
  assert.equal(r.score, 40);
});

test('encryption-like behaviour reaches "alert"', () => {
  const a = new Analyzer();
  const now = 1_000_000;
  const changes = [];
  for (let i = 0; i < 8; i++) {
    changes.push({ kind: 'renamed', path: `d/f${i}.docx.locked`, from: `d/f${i}.docx`, appended: true, ent: 7.9, prevEnt: 7.9 });
  }
  changes.push({ kind: 'created', path: 'd/HOW_TO_DECRYPT_FILES.txt', ent: 4, prevEnt: null });
  a.ingest(changes, now);
  const r = a.assess(now + 500);
  assert.equal(r.level, 'alert');
  assert.ok(r.score >= 90);
  assert.ok(r.reasons.length >= 3);
});

test('score decays once the windows pass', () => {
  const a = new Analyzer();
  const now = 1_000_000;
  a.ingest(Array.from({ length: 10 }, (_, i) => ({ kind: 'created', path: `x${i}.locked`, ent: 7.9, prevEnt: null })), now);
  assert.equal(a.assess(now + 100).level, 'alert');
  assert.equal(a.assess(now + 61_000).level, 'calm');
});

test('configurable threshold', () => {
  const a = new Analyzer({ threshold: 4 });
  const now = 1_000_000;
  a.ingest(Array.from({ length: 4 }, (_, i) => ({ kind: 'modified', path: `f${i}.txt`, ent: 4, prevEnt: 4 })), now);
  assert.equal(a.assess(now).level, 'watch');
});
