# Ransomware Detection Dashboard

A Flask web dashboard for the original Tkinter + Watchdog file-activity monitor.

## Important limitation

**GitHub Pages cannot run this Python app.** GitHub can host this source repository, but the Flask server and Watchdog monitor must run on a computer or a Python-capable host. When hosted remotely, it watches files on that host—not files on a visitor's personal computer.

## Run locally

1. Install Python 3.10 or newer.
2. Open a terminal in this project folder.
3. Install dependencies:

   ```bash
   python -m pip install -r requirements.txt
   ```

4. Start the app:

   ```bash
   python app.py
   ```

5. Open `http://127.0.0.1:5000` in your browser.
6. Add, edit, or rename a harmless test file inside `test_files/` to see events appear.

The app starts monitoring automatically. Use the dashboard buttons to start/stop monitoring and clear the displayed event feed.

## Upload to GitHub

1. Create a new repository on GitHub.
2. Upload `app.py`, `detector.py`, `logger.py`, `requirements.txt`, `.gitignore`, `README.md`, and the `templates/`, `static/`, and `test_files/` folders.
3. Commit and push the files.
4. To make it accessible online, deploy the repository to a Python-capable hosting provider that supports a persistent background process. Configure the start command as:

   ```bash
   gunicorn app:app
   ```

   Add `gunicorn` to `requirements.txt` if your hosting provider requires it. Use a persistent service; serverless/sleeping environments may stop the file observer.

## Detection notes

The detector flags 10 file activity events within 5 seconds. This is a basic heuristic and may produce false positives. It is not a full ransomware detector: it does not inspect file contents, identify encryption, or prevent changes. Test only with files you own. Do not use this prototype as your only security control.
