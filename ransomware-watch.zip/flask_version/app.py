import os
import threading
from collections import deque
from datetime import datetime
from flask import Flask, jsonify, render_template, request
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from detector import RansomwareDetector
from logger import log_event

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TEST_FOLDER = os.path.join(BASE_DIR, "test_files")
os.makedirs(TEST_FOLDER, exist_ok=True)

app = Flask(__name__)
events = deque(maxlen=300)
state = {"warning": False, "monitoring": False, "folder": TEST_FOLDER}
state_lock = threading.Lock()
observer = None

def add_event(event_type, details, level="INFO"):
    item = {
        "time": datetime.now().strftime("%H:%M:%S"),
        "type": event_type,
        "details": details,
        "level": level,
    }
    with state_lock:
        events.appendleft(item)
    log_event(event_type, details)

class FileMonitor(FileSystemEventHandler):
    def __init__(self):
        super().__init__()
        self.detector = RansomwareDetector(threshold=10, window=5)

    def _handle(self, path, event_type):
        if os.path.isdir(path):
            return
        filename = os.path.basename(path)
        suspicious = self.detector.record_event()
        add_event(event_type, f"{event_type}: {filename}")
        if suspicious:
            with state_lock:
                already_warned = state["warning"]
                state["warning"] = True
            if not already_warned:
                add_event("WARNING", "Unusually frequent file activity detected. Investigate before deciding whether it is malicious.", "WARNING")

    def on_modified(self, event):
        if not event.is_directory:
            self._handle(event.src_path, "Modified")

    def on_created(self, event):
        if not event.is_directory:
            self._handle(event.src_path, "Created")

    def on_moved(self, event):
        if not event.is_directory:
            self._handle(event.dest_path, "Moved")

def start_monitoring():
    global observer
    with state_lock:
        if state["monitoring"]:
            return
    os.makedirs(TEST_FOLDER, exist_ok=True)
    handler = FileMonitor()
    new_observer = Observer()
    new_observer.schedule(handler, TEST_FOLDER, recursive=True)
    new_observer.start()
    observer = new_observer
    with state_lock:
        state["monitoring"] = True
        state["warning"] = False
    add_event("SYSTEM", "Monitoring started for the test_files folder.")

def stop_monitoring():
    global observer
    with state_lock:
        running = state["monitoring"]
        state["monitoring"] = False
    if running and observer:
        observer.stop()
        observer.join(timeout=3)
        observer = None
    add_event("SYSTEM", "Monitoring stopped.")

@app.route("/")
def index():
    return render_template("index.html")

@app.get("/api/status")
def api_status():
    with state_lock:
        return jsonify({
            "monitoring": state["monitoring"],
            "warning": state["warning"],
            "folder": state["folder"],
            "event_count": len(events),
        })

@app.get("/api/events")
def api_events():
    with state_lock:
        return jsonify(list(events))

@app.post("/api/monitor/start")
def api_start():
    start_monitoring()
    return jsonify({"ok": True, "message": "Monitoring started."})

@app.post("/api/monitor/stop")
def api_stop():
    stop_monitoring()
    return jsonify({"ok": True, "message": "Monitoring stopped."})

@app.post("/api/monitor/reset")
def api_reset():
    with state_lock:
        events.clear()
        state["warning"] = False
    add_event("SYSTEM", "Dashboard event log cleared.")
    return jsonify({"ok": True})

if __name__ == "__main__":
    start_monitoring()
    try:
        app.run(host="127.0.0.1", port=int(os.environ.get("PORT", "5000")), debug=False)
    finally:
        stop_monitoring()
