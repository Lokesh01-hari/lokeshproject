import time
from collections import deque

class RansomwareDetector:
    """Simple activity-rate heuristic; it flags bursts, not confirmed ransomware."""
    def __init__(self, threshold=10, window=5):
        self.threshold = threshold
        self.window = window
        self.timestamps = deque()

    def record_event(self):
        now = time.time()
        self.timestamps.append(now)
        while self.timestamps and now - self.timestamps[0] > self.window:
            self.timestamps.popleft()
        return len(self.timestamps) >= self.threshold
