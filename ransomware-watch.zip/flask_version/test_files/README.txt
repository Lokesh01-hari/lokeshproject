Put sample files you own in this folder to test file activity monitoring. The app watches this folder only.
