import os
from datetime import datetime
from threading import Lock

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_FILE = os.path.join(BASE_DIR, "activity.log")
_lock = Lock()

def log_event(event_type, details):
    line = f"{datetime.now().isoformat(timespec='seconds')} | {event_type} | {details}\n"
    with _lock:
        with open(LOG_FILE, "a", encoding="utf-8") as log:
            log.write(line)
